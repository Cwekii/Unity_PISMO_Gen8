﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TimerAdding : MonoBehaviour
{
    public Text timerText;
    public float timeCount = 0;
    [Header("Do koliko minuta igrač može igrati, ako je limit 0 onda ide u beskonačno")]
    public int limit;

    private void Start()
    {
        limit *= 60;
    }

    private void Update()
    {
        timeCount += Time.deltaTime;
        if(limit == 0)
        {
            //Dijelimo sa cijelim brojem 60 da dobijemo minute
            int minutes = (int)timeCount / 60;
            //Djelimo sa 60 da dobijemo ostatak za sekunde
            //int seconds = (int)allTime % 60;
            int seconds = Mathf.FloorToInt(timeCount % 60);

            //ako je manje od 10 za minute i sekunde //2:4
            if (minutes < 10 && seconds < 10)
            {
                timerText.text = "0" + minutes + ":" + "0" + seconds; //02:04
            }

            //Ako su minute jednoznamenkaste, a sekunde dvoznamenkaste //4:19
            else if (minutes < 10 && seconds >= 10)
            {
                timerText.text = "0" + minutes + ":" + seconds; //04:19
            }

            //Ako su minute dvoznamenkaste, a sekunde jednoznamenkaste
            else if (minutes >= 10 && seconds < 10)
            {
                timerText.text = minutes + ":" + "0" + seconds;
            }

            //Minute i sekunde su dvoznamenkaste
            else
            {
                timerText.text = minutes + ":" + seconds;
            }


        }

        if (timeCount <= limit)
        {
            //Dijelimo sa cijelim brojem 60 da dobijemo minute
            int minutes = (int)timeCount / 60;
            //Djelimo sa 60 da dobijemo ostatak za sekunde
            //int seconds = (int)allTime % 60;
            int seconds = Mathf.FloorToInt(timeCount % 60);

            //ako je manje od 10 za minute i sekunde //2:4
            if (minutes < 10 && seconds < 10)
            {
                timerText.text = "0" + minutes + ":" + "0" + seconds; //02:04
            }

            //Ako su minute jednoznamenkaste, a sekunde dvoznamenkaste //4:19
            else if (minutes < 10 && seconds >= 10)
            {
                timerText.text = "0" + minutes + ":" + seconds; //04:19
            }

            //Ako su minute dvoznamenkaste, a sekunde jednoznamenkaste
            else if (minutes >= 10 && seconds < 10)
            {
                timerText.text = minutes + ":" + "0" + seconds;
            }

            //Minute i sekunde su dvoznamenkaste
            else
            {
                timerText.text = minutes + ":" + seconds;
            }

        }
    }
}
